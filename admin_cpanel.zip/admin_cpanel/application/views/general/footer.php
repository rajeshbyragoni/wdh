<!-- Footer -->
<footer class="main">				
	&copy; <?php echo date('Y'); ?> <a href="http://utravel.com/" target="_blank"><strong>Utravel.com</strong> Powered by: <a href="http://www.provab.com" target="_blank">Provab</a>
</footer>
