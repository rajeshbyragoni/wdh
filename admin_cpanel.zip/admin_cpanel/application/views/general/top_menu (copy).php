<?php if(false){ ?>
			<div class="row">
				<div class="col-sm-2">				
					<div class="tile-stats tile-green">
						<div class="icon"><i class="entypo-users"></i></div>
						<div class="num" data-start="0" data-end="83" data-postfix="" data-duration="1500" data-delay="0">0</div>
						<h3>B2C users</h3>
					</div>					
				</div>
				
				<div class="col-sm-2">				
					<div class="tile-stats tile-red">
						<div class="icon"><i class="entypo-users"></i></div>
						<div class="num" data-start="0" data-end="5" data-postfix="" data-duration="1500" data-delay="600">0</div>
						<h3>B2B users</h3>
					</div>					
				</div>
				
				<div class="col-sm-2">				
					<div class="tile-stats tile-brown">
						<div class="icon"><i class="entypo-chart-bar"></i></div>
						<div class="num" data-start="0" data-end="135" data-postfix="" data-duration="1500" data-delay="600">0</div>
						<h3>Visitors</h3>
					</div>					
				</div>
				
				<div class="col-sm-2">				
					<div class="tile-stats tile-aqua">
						<div class="icon"><i class="entypo-mail"></i></div>
						<div class="num" data-start="0" data-end="23" data-postfix="" data-duration="1500" data-delay="1200">0</div>
						<h3>Messages</h3>
					</div>
				</div>
				
				<div class="col-sm-2">				
					<div class="tile-stats tile-cyan">
						<div class="icon"><i class="entypo-rss"></i></div>
						<div class="num" data-start="0" data-end="52" data-postfix="" data-duration="1500" data-delay="1800">0</div>
						<h3>Booking</h3>
					</div>					
				</div>
				
				<div class="col-sm-2">				
					<div class="tile-stats tile-blue">
						<div class="icon"><i class="entypo-rss"></i></div>
						<div class="num" data-start="0" data-end="52" data-postfix="" data-duration="1500" data-delay="1800">0</div>
						<h3>Subscribers</h3>
					</div>					
				</div>
			</div>
<?php } ?>
			<br />
