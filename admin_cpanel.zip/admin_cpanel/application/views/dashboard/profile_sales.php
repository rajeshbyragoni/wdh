
				<div class="col-sm-4">
					
					<div class="panel panel-primary">
						<table class="table table-bordered table-responsive">
							<thead>
								<tr>
									<th class="padding-bottom-none text-center">
										<br />
										<br />
										<span class="monthly-sales"></span>
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td class="panel-heading">
										<h4>Monthly Sales</h4>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					
				</div>
				
				<div class="col-sm-8">
					
					<div class="panel panel-primary">
						<div class="panel-heading">
							<div class="panel-title">Latest Updated Profiles</div>
							
							<div class="panel-options">
								<a href="#sample-modal" data-toggle="modal" data-target="#sample-modal-dialog-1" class="bg"><i class="entypo-cog"></i></a>
								<a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
								<a href="#" data-rel="reload"><i class="entypo-arrows-ccw"></i></a>
								<a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
							</div>
						</div>
							
						<table class="table table-bordered table-responsive">
							<thead>
								<tr>
									<th>#</th>
									<th>Name</th>
									<th>Position</th>
									<th>Activity</th>
								</tr>
							</thead>
							
							<tbody>
								<tr>
									<td>1</td>
									<td>Art Ramadani</td>
									<td>CEO</td>
									<td class="text-center"><span class="inlinebar">4,3,5,4,5,6</span></td>
								</tr>
								
								<tr>
									<td>2</td>
									<td>Filan Fisteku</td>
									<td>Member</td>
									<td class="text-center"><span class="inlinebar-2">1,3,4,5,3,5</span></td>
								</tr>
								
								<tr>
									<td>3</td>
									<td>Arlind Nushi</td>
									<td>Co-founder</td>
									<td class="text-center"><span class="inlinebar-3">5,3,2,5,4,5</span></td>
								</tr>

							</tbody>
						</table>
					</div>
					
				</div>
				