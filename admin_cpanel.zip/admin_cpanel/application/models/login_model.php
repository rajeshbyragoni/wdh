<?php
class Login_Model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }    
}
?>
